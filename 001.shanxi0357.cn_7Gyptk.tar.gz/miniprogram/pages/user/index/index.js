import {
    request
} from "../../../utils/request";

Page({
    data: {
        week: '',
        user: getApp().globalData.loginUser
    },
    onLoad: function () {
        let _this = this
        _this.getWeek()
    },
    getWeek: function () {
        let _this = this
        let week = '周' + '日一二三四五六'.charAt(new Date().getDay());
        _this.setData({
            week: week
        })
    },
    bindGetUserInfo: function (e) {
        let _this = this
        wx.showLoading({
            mask: true
        })
        wx.login({
            success: (res) => {
                request('/user/updateUser', {
                    code: res.code,
                    iv: e.detail.iv,
                    encryptedData: e.detail.encryptedData
                }).then((res) => {
                    if (res.code == 0) {
                        wx.showToast({
                            title: res.msg,
                            icon: 'none',
                            mask: true
                        })
                    } else {
                        getApp().globalData.loginUser = res.data.user
                        wx.setStorageSync('loginUser', res.data.user)
                        _this.setData({
                            user: res.data.user
                        })
                    }
                    wx.hideLoading()
                })
            },
        })
    },
    logoutTap() {
        let _this = this
        if (_this.data.user) {
            wx.showModal({
                title: '提示',
                content: '确认退出？',
                complete: (res) => {
                    if (res.confirm) {
                        getApp().getCode()
                        getApp().globalData.loginUser = null
                        wx.removeStorageSync('loginUser')
                        _this.setData({
                            user: null
                        })
                    }
                }
            })
        }
    },
    exonerationTap() {
        wx.navigateTo({
            url: '/pages/user/exoneration/exoneration',
        })
    }
})