Component({
    properties: {
        list: {
            type: Array
        }
    },
    methods:{}
})