Component({
    properties: {
        list: {
            type: Array
        },
        type: {
            type: Number
        }
    },
    methods: {}
})