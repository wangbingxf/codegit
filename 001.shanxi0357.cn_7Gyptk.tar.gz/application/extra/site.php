<?php

return array (
  'name' => '彩票开奖查询',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.1',
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'languages' => 
  array (
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ),
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => '默认',
    'page' => '单页',
    'article' => '文章',
    'test' => 'Test',
  ),
  'configgroup' => 
  array (
    'basic' => '基础配置',
    'email' => '邮件配置',
    'dictionary' => '字典配置',
    'user' => '会员配置',
    'web' => '网站配置',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '10000',
  'mail_smtp_pass' => 'password',
  'mail_verify_type' => '2',
  'mail_from' => '10000@qq.com',
  'attachmentcategory' => 
  array (
    'category1' => '分类一',
    'category2' => '分类二',
    'custom' => '自定义',
  ),
  'appid' => 'wx7674e49338c31a17',
  'appsecret' => '9d823bc1774f38649d17e1f4f8172187',
  'copyright' => '小程序数据来源：      中国福利彩票官网:http://www.cwl.gov.cn 中国体育彩票官网:https://www.lottery.gov.cn',
  'exoneration' => '<div>当前，国家发文禁止网络售彩，建议彩民前往实体，线下，合法的投注站购买彩票。</div><div><br></div><div>小程序只是提供开奖信息查询服务，不对交易承担任何责任。</div><div><br></div>',
  'message' => '本小程序仅提供彩票开奖查询，不提供线上销售彩票.彩交.模拟.推荐！',
  'interstitialAdUnitId' => '',
  'indexBannerAdUnitId' => '',
  'detailBannerAdUnitId' => '',
  'subscriptionTemplateId' => 'WMPy3f9D_XnoyfIjkmdMjZWnviegDKQ0765_OYDQnsg',
);
