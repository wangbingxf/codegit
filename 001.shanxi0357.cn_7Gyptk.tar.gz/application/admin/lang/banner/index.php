<?php

return [
    'Id' => '序号',
    'Image' => '图片',
    'Sort' => '排序',
    'Created_at' => '创建时间',
    'Updated_at' => '更新时间'
];
